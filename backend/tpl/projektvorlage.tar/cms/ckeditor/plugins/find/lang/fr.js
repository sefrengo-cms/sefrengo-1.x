﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'find', 'fr', {
	find: 'Trouver',
	findOptions: 'Options de recherche',
	findWhat: 'Expression à trouver: ',
	matchCase: 'Respecter la casse',
	matchCyclic: 'Boucler',
	matchWord: 'Mot entier uniquement',
	notFoundMsg: 'Le texte spécifié ne peut être trouvé.',
	replace: 'Remplacer',
	replaceAll: 'Remplacer tout',
	replaceSuccessMsg: '%1 occurrence(s) replacée(s).',
	replaceWith: 'Remplacer par: ',
	title: 'Trouver et remplacer'
});
