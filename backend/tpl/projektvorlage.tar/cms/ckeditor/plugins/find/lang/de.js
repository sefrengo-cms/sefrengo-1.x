﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'find', 'de', {
	find: 'Suchen',
	findOptions: 'Suchoptionen',
	findWhat: 'Suche nach:',
	matchCase: 'Groß-Kleinschreibung beachten',
	matchCyclic: 'Zyklische Suche',
	matchWord: 'Nur ganze Worte suchen',
	notFoundMsg: 'Der gesuchte Text wurde nicht gefunden.',
	replace: 'Ersetzen',
	replaceAll: 'Alle ersetzen',
	replaceSuccessMsg: '%1 vorkommen ersetzt.',
	replaceWith: 'Ersetze mit:',
	title: 'Suchen und Ersetzen'
});
